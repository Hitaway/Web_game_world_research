<footer>
	<div class="container footer-copyright py-3 text-center">
		<p id="texte_copyrigth">© 2018 Company, Inc.</p>
		<p id="texte_nom_dev">Réalisé par : Quentin Rat et Slimane Kouba</p>
	</div>
</footer>