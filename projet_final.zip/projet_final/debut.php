<!DOCTYPE html>
<html lang="fr">
<head>
 	<meta charset="utf-8">
 	<title>Research</title>
 	<link rel="stylesheet" type="text/css" href="accueil.css">
 	<link rel="shortcut icon" href="Image/icone.ico">
 	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  	<script src="javascript.js"></script>
</head>
